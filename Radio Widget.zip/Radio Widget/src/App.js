import './App.css';
import Widget from './Widget';

function App() {
  return (
      <div>
        <Widget/>
      </div>
  );
}

export default App;
